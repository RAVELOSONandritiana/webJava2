<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>espace administrateur</title>
    <link rel="stylesheet" href="style_admin.css">
</head>
<body>
    <?php
        function printInput($connexion)
        {
            $resultat = mysqli_query($connexion,"select * from inscrit");
            echo "<form action=\"afficher_reussi.php\" method=\"get\">";
            echo "<table>";
            echo "<tr><td>motif</td><td>point</td></tr>";
            $tab_motif = [];
            $cpt = 0;
            while($row = mysqli_fetch_assoc($resultat))
            {
                if(!in_array($row['motif'],$tab_motif)){
                    $tab_motif[] = $row['motif'];
                }
            }
            foreach($tab_motif as $element)
            {
                echo "<tr>";
                    echo "<td>$element</td>";
                    echo "<td><input type=\"number\" name=\"motif$cpt\"></td>";
                echo "</tr>";
                $cpt++;
            }
            echo "</table>";
            echo "<input type=\"submit\">";
            echo "</form>";
        }

        $serveur = "localhost";
        $utilisateur = "michel";
        $motdepasse = "123456";
        $base = "personne";

        $connexion = mysqli_connect($serveur, $utilisateur, $motdepasse, $base);

        if (!$connexion) {
            echo "La connexion a la base de donne a echoue<br>";
        }
        else{
            echo "connexion a la base de donne reussie<br>";
        }
        printInput($connexion);
        mysqli_close($connexion);

    ?>

</body>
</html>