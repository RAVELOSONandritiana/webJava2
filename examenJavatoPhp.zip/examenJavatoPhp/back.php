<?php
function verification($connexion,$info_personne_total){
    $tab = explode(":",$info_personne_total);
    $requete = "select * from inscrit";
    $resultat = mysqli_query($connexion,$requete);
    while($row = mysqli_fetch_assoc($resultat)){
        if($tab[0] == $row['nom'] && $tab[1] == $row['prenom'] && $tab[2] == $row['age'] && $tab[3] == $row['motif']){
            return "In";
        }
    }
    return "notIn";
}

function ajout($connexion,$info_personne_total){
    $tab = explode(":",$info_personne_total);
    $nom = $tab[0];
    $prenom = $tab[1];
    $age = $tab[2];
    $motif = $tab[3];
    if(verification($connexion,$info_personne_total) == "notIn"){
        $requete = "insert into inscrit (nom,prenom,age,motif) values ('$nom','$prenom',$age,'$motif')";
        mysqli_query($connexion, $requete);
    }
}

$nom = $_GET['nom'];
$prenom = $_GET['prenom'];
$age = $_GET['age'];
$motif = $_GET['motif'];
$info_personne_total = "$nom:$prenom:$age:$motif";
//partie connexion a la base de donne
/**********************************************************/
$serveur = "localhost";
$utilisateur = "michel";
$motdepasse = "123456";
$base = "personne";

$connexion = mysqli_connect($serveur, $utilisateur, $motdepasse, $base);

if (!$connexion) {
    echo "La connexion a la base de donne a echoue<br>";
}
else{
    echo "connexion a la base de donne reussie<br>";
}

ajout($connexion,$info_personne_total);
mysqli_close($connexion);
header("Location: main.html");
/**********************************************************/
?>