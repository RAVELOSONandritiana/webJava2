<?php
    $tab_point = [];
    $serveur = "localhost";
    $utilisateur = "michel";
    $motdepasse = "123456";
    $base = "personne";

    $connexion = mysqli_connect($serveur, $utilisateur, $motdepasse, $base);

    if (!$connexion) {
        echo "La connexion a la base de donne a echoue<br>";
    }
    else{
        echo "connexion a la base de donne reussie<br>";
    }

    function countLigne($connexion){
        $resultat = mysqli_query($connexion,"select * from inscrit");
        $cpt = 0;
        $tab_motif = [];
        while($row = mysqli_fetch_assoc($resultat))
            {
                if(!in_array($row['motif'],$tab_motif)){
                    $tab_motif[] = $row['motif'];
                }
            }
        return count($tab_motif);
    }
    $tab_motif = [];
    $resultat = mysqli_query($connexion,"select * from inscrit");
        $tab_motif = [];
        while($row = mysqli_fetch_assoc($resultat))
        {
            if(!in_array($row['motif'],$tab_motif)){
                $tab_motif[] = $row['motif'];
            }
        }
    $get = [];
    for($i = 0;$i < countLigne($connexion);$i++)
    {
        $r = "motif$i";
        $get[] = $_GET[$r];
    }

    function printPersonne($connexion,$tab_motif,$get)
    {
        $tableau = [];
        $i = 0;
        $resultat = mysqli_query($connexion,"select * from inscrit");
        while($row = mysqli_fetch_assoc($resultat))
        {
            $nom = $row['nom'];
            $prenom = $row['prenom'];
            $age = $row['age'];
            $motif = $row['motif'];
            $index = 0;
            for($i = 0;$i < count($get);$i++)
            {
                if($motif == $tab_motif[$i])
                {
                    $index = $i;
                    break;
                }
            }
            $point = $get[$index];
            $tableau[] = [$nom,$prenom,$age,$motif,$point];
        }

        for($i = 0;$i < countLigne($connexion);$i++)
        {
            for($j =0;$j < countLigne($connexion);$j++)
            {
                if((int)$tableau[$i][4] < (int)$tableau[$j][4])
                {
                    $t = $tableau[$i];
                    $tableau[$i] = $tableau[$j];
                    $tableau[$j] = $t;
                }
            }
        }

        echo "Les 3 personnes qui vont recevoir le don de mon association sont<br>";
        for($j = count($tableau)-1;$j > count($tableau)-4;$j--)
        {
            echo "<pre>";
            print_r($tableau[$j]);
            echo "</pre>";
        }
    }

    printPersonne($connexion,$tab_motif,$get);


?>