Ce programme essaye de trier les gens qui vont meriter d un don d une associaton
Les personnes ne peuvent pas metter 2fois ou plus leur nom dans la liste
le programme ne gere pas encore le cas ou la personne a obtenu un don et met deja une autre demande
Les motifs de tris est encore une seule parametre
manuel:
ouvrir http://localhost:8080/data/demand.html pour inscrire au demande de don
http://localhost:8080/data/MotifData pour noter les motifs (reserve au administrateur mais il n y a pas encore de gestion de compte)
apres , il va trier les 3 premieres personnes qui vont pouvoir obtenir les dons
