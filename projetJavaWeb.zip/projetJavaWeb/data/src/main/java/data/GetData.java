package data;

import java.io.IOException;
import java.util.ArrayList;

public class GetData {
	ArrayList<String> data;
	public GetData() throws IOException {
		Personne p = new Personne();
		for(String i:p.getMotif()) {
			data.add(i);
		}
	}

}
