package data;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class Personne {
	String nom;
	String prenom;
	int age;
	String motif;
	int point = 0;
	public Personne() {
		
	}

	public void setInformation(String nom,String prenom,int age,String motif) {
		this.nom = nom;
		this.prenom = prenom;
		this.age = age;
		this.motif = motif;
	}
	public String getInfo() {
		return nom+"/"+prenom+"/"+age+"/"+motif;
	}
	public int writeInFile(String fichier) throws IOException {
		String data = nom+"/"+prenom+"/"+age+"/"+motif;
		if(testData()==1 && verifInFIleName("/home/misa/Bureau/aide.txt",this.nom,this.prenom,this.age) == "false" && verifInFile("/home/misa/Bureau/dataDemande.txt",data)=="false") {
			try (FileWriter file = new FileWriter(fichier,true)) {
				file.write(data+"\n");
			}
			return 1;
		}
		return 0;
	}

	public int testData() {
		if(nom == "" || prenom == "" || motif == "") {
			return 0;
		}
		return 1;
	}
	public String []getLinesInFile(String titre) throws IOException{
		try (FileReader file = new FileReader(titre)) {
			int data = 0;
			String chaine = "";
			while((data = file.read())!=-1) {
				chaine+=(char)data;
			}
			return chaine.split("\n");
		}
	}
	
	public String verifInFile(String fichier,String texte) throws IOException {
		if(testFile(fichier) == 0) {
			try (FileWriter file = new FileWriter(fichier)) {
				file.write("");
			}
		}
		String []lines = getLinesInFile(fichier);
		for(String i:lines) {
			if(i.equals(texte)) {
				return "true";
			}
		}
		return "false";
	}
	
	public String verifInFIleName(String fichier,String nom,String prenom,int age) throws IOException {
		if(testFile(fichier) == 0) {
			try (FileWriter file = new FileWriter(fichier)) {
				file.write("");
			}
		}
		String []lines = getLinesInFile(fichier);
		for(String i:lines) {
			if((i.split("/")[0]).equals(nom) && (i.split("/")[1]).equals(nom) && Integer.parseInt(i.split("/")[2]) == this.age) {
				return "true";
			}
		}
		return "false";
	}

	public String motif() throws IOException {
		String []lines = getLinesInFile("/home/misa/Bureau/dataDemande.txt");
		String m = lines[0].split("/")[3].split("\n")[0];
		return m;
	}
	
	public void setPoint(int p) {
		this.point += p;
	}
	
	public int getPoint() {
		return this.point;
	}
	public ArrayList<String> getMotif() throws IOException {
		String []lines = getLinesInFile("/home/misa/Bureau/dataDemande.txt");
		ArrayList<String> motif = new ArrayList<String>();
		for(String i:lines) {
			motif.add(i.split("/")[3]);
		}
		return motif;
	}
	
	public void delLines(String fichier) throws IOException{
		try(FileWriter file = new FileWriter(fichier,false)){
			file.write("");
		}
	}
	
	public int testFile(String fichier) {
		File file = new File(fichier);
		if(file.exists()) {
			return 1;
		}
		return 0;
	}

}
