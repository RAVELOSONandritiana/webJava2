import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import data.Personne;

@WebServlet("/ListeAccepte")
public class ListeAccepte extends HttpServlet {
    private static final long serialVersionUID = 1L;
 
    public ListeAccepte() {
        super();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        PrintWriter out = response.getWriter();
        out.println("<!DOCTYPE html>");
        out.println("<html>");
        out.println("<head>");
        out.println("<title>Liste Acceptee</title>");
        out.println("<style>");
        out.println("table { width: 50%; border-collapse: collapse; margin: 20px auto; animation: fadeIn 1s ease-in-out; }");
        out.println("th, td { border: 1px solid #dddddd; padding: 8px; text-align: left; }");
        out.println("th { background-color: #f2f2f2; }");
        out.println("@keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }");
        out.println(".fade { animation: fadeOut 1s ease-in-out; }");
        out.println("@keyframes fadeOut { from { opacity: 1; } to { opacity: 0; } }");
        out.println("table.fade:hover { box-shadow: 0px 0px 10px 0px rgba(0,0,0,0.3); }");
        out.println("table.fade th:hover { background-color: #e0e0e0; }");
        out.println("table.fade td:hover { background-color: #f9f9f9; }");
        out.println("</style>");
        out.println("</head>");
        out.println("<body>");
         
        out.println("<h2 style=\"text-align:center;\">Liste Acceptee</h2>");
        int nombre = 3;
        Personne personne = new Personne();
        ArrayList<String> liste_res_name = personne.getMotif();
        String []fichier = personne.getLinesInFile("/home/misa/Bureau/dataDemande.txt");
        ArrayList<Integer> liste_value = new ArrayList<Integer>();
        ArrayList<Integer> index = new ArrayList<Integer>();
        for (int i = 0; i < liste_res_name.size(); i++) {
            String varName = request.getParameter("motif" + i);
            liste_value.add(Integer.parseInt(varName));
            index.add(i);
        }
//        for (int i = 0; i < liste_res_name.size(); i++) {
//            int max = i;
//            for (int j = i + 1; j < liste_res_name.size(); j++) {
//                if (liste_value.get(index.get(max)) < liste_value.get(index.get(j))) {
//                    max = j;
//                }
//            }
//            int temp = index.get(i);
//            index.set(i, index.get(max));
//            index.set(max, temp);
//        }
//
        ArrayList<String> finale = new ArrayList<String>();
        for(int i = 0;i < liste_res_name.size();i++) {
        	finale.add(fichier[index.get(i)]);
        }
//
//        out.println("<table class=\"fade\">");
//        out.println("<tr><th>Points</th><th>Motif</th></tr>");
//        for (int i = 0; i < liste_res_name.size(); i++) {
//            String varName = ""+liste_value.get(index.get(i));
//            String resName = liste_res_name.get(index.get(i));
//            out.println("<tr>");
//            out.println("<td>" + varName + "</td>");
//            out.println("<td>" + resName + "</td>");
//            out.println("</tr>");
//        }
        /*******************************/
        ArrayList<Personne> pers = new ArrayList<Personne>();
        for(int i = 0;i < liste_res_name.size();i++) {
        	Personne p = new Personne();
        	String []u = (fichier[i]).split("/");
        	p.setInformation(u[0],u[1],Integer.parseInt(u[2]),u[3]);
        	pers.add(p);
        }

        for(int i = 0;i < liste_res_name.size();i++) {
        	Personne p = pers.get(i);
			p.setPoint(liste_value.get(i));
			pers.set(i, p);
        }

       for(int i = 0;i < liste_res_name.size();i++) {
    	   for(int j = i+1;j < liste_res_name.size();j++) {
    		   Personne p1 = pers.get(i);
    		   Personne p2 = pers.get(j);
    		   if(p1.getPoint() < p2.getPoint()) {
    			   pers.set(i, p2);
    			   pers.set(j, p1);
    		   }
    	   }
       }

        /*******************************/
		 out.println("<table class=\"fade\">");
		 out.println("<tr><th>Points</th><th>Motif</th></tr>");
		 for (int i = 0; i < liste_res_name.size(); i++) {
			 Personne p = pers.get(i);
			 out.println("<tr>");
			 out.println("<td>" + p.getPoint() + "</td>");
			 out.println("<td>" + p.motif() + "</td>");
			 out.println("</tr>");
		 }
        
        out.println("</table>");
        out.println("<table class=\"fade\">");
        out.println("<tr><th>Nom</th><th>Prenom</th><th>Age</th><th>Motif</th></tr>");
        for (int i = 0; i < nombre; i++) {
            Personne p = pers.get(i);
            out.println("<tr>");
            for(String j:(p.getInfo()).split("/")) {
            	out.println("<td>" + j + "</td>");
            }
            out.println("</tr>");
        }
        
        out.println("</table>");
        
        out.println("</body>");
        out.println("</html>");
        
        for(int i = 0;i < nombre;i++) {
        	Personne p = pers.get(i);
        	p.writeInFile("/home/misa/Bureau/aide.txt");
        	p.delLines("/home/misa/Bureau/dataDemande.txt");
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}
