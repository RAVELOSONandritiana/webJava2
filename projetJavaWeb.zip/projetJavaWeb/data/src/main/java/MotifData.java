import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import data.Personne;

/**
 * Servlet implementation class MotifData
 */
@WebServlet("/MotifData")
public class MotifData extends HttpServlet {
    private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MotifData() {
        super();
        // TODO Auto-generated constructor stub
    }

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // TODO Auto-generated method stub
        //response.getWriter().append("Served at: ").append(request.getContextPath());
        Personne personne = new Personne();
        PrintWriter out = response.getWriter();
        response.setContentType("text/html");
        out.println("<!DOCTYPE html>");
        out.println("<html>");
        out.println("<head>");
        out.println("<meta charset=\"UTF-8\">");
        out.println("<title>Motif Data</title>");
        out.println("<style>");
        out.println("body { font-family: Arial, sans-serif; margin: 0; padding: 0; }");
        out.println("h2 { color: #fff; text-align: center; background-color: #007bff; padding: 20px 0; margin: 0; }");
        out.println("table { border-collapse: collapse; width: 50%; margin: auto; background-color: rgba(255, 255, 255, 0.8); box-shadow: 0 0 10px rgba(0,0,0,0.1); }");
        out.println("th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }");
        out.println("tr:nth-child(even) { background-color: #f2f2f2; }");
        out.println("th { background-color: #007bff; color: white; }");
        out.println("input[type=\"number\"] { width: 100%; padding: 8px; box-sizing: border-box; }");
        out.println("button { background-color: #007bff; color: white; padding: 12px 20px; margin: 10px 0; border: none; cursor: pointer; width: 100%; }");
        out.println("</style>");
        out.println("</head>");
        out.println("<body>");
        out.println("<h2>Notez les motifs</h2>");
        out.println("<table>");
        ArrayList<String> variable_name = new ArrayList<>();
        int cpt = 0;
        out.println("<form method=\"get\" action=\"http://localhost:8080/data/ListeAccepte\"");
        for(String i : personne.getMotif())
        {
            out.println("<tr>");
            out.println("<td>" + i + "</td>");
            out.println("<td><input type=\"number\" value = 0 name=\"motif" + cpt + "\"></td>");
            cpt++;
            out.println("</tr>");
        }
        out.println("<input type=\"submit\">");
        out.println("</form>");
        out.println("</table>");
        // Ici, vous pouvez rediriger ou effectuer une autre action avec les données
        out.println("</body>");
        out.println("</html>");
    }

    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // TODO Auto-generated method stub
        doGet(request, response);
    }
}